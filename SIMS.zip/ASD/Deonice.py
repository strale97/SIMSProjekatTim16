'''
Created on Jul 13, 2018

@author: marko
'''


class Deonice(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        self.listaDeonica = ["Aleksinac", "Aleksinacki Rudnici", "Batocina", "Backa Topola", 
                             "Beograd", "Beska", "Dimitrovgrad", "Doljevac", "Feketic", 
                             "Indjija", "Jagodina", "Kolari", "Kovilj", "Kuzmin", "Lapovo", 
                             "Mali Pozarevac", "Maradik", "Markovac", "Morovic", "Nis", 
                             "Novi Sad", "Paracin", "Pecinci", "Pojate", "Pozarevac", 
                             "Preljina", "Presevo", "Razanj", "Ruma", "Smederevo", 
                             "Sremska Mitrovica", "Subotica", "Takovo", "Umcari", 
                             "Velika Plana", "Vodanj", "Vrbas", "Zmajevo", "Cuprija", 
                             "Sid", "Zednik"]
        
