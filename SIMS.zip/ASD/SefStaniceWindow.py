'''
Created on Jul 13, 2018

@author: marko
'''
from PySide.QtGui import QMainWindow

class SefStaniceWindow(QMainWindow):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        super(SefStaniceWindow, self).__init__()