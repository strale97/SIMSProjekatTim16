'''
Created on Jul 13, 2018

@author: marko
'''
from PySide.QtGui import QMainWindow, QLabel, QRadioButton, \
    QGridLayout, QMessageBox, QWidget, QApplication
from MyWidget1 import MyWidget1


class NaplatnoMestoWindow(QMainWindow):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        super(NaplatnoMestoWindow, self).__init__()
        self.resize(800,600)

        user = QApplication.instance().currentUser
        
        
        widget = MyWidget1()
        
        
        self.setCentralWidget(widget)
        
        
        
        
        
        
        
        
        
        
        